# angular-web-survey
An angular app that display a web page for a survey.

Uses material design components for the UI.

There was supposed to be a login and signup screen at first, didn't get around to those in time. The prompt says to keep it under 4 hours and some Angular setup wasted some time unfortunately.
The survey portion should be complete minus a service call to a would-be API app, though.

# Running
See package.json for dependencies. It should be pretty minimal but requires Node and Angular CLI installed.

Run 'npm install' from command line to get project dependencies.

Run 'ng serve' to compile and run the code. Page will be hosted at localhost:4200
